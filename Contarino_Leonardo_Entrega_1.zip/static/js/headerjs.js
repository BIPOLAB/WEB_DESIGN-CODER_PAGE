var header = document.getElementById('Header')
var logo = document.getElementById('logo')

window.addEventListener('scroll',()=>{
    var scroll = window.scrollY
    if (scrollY >10){
        header.style.backgroundColor = 'rgba(107, 186, 167,0.7)';
        
    }
    else{
        header.style.backgroundColor = 'rgb(107, 186, 167)';
        logo.style.backgroundColor='#202020';

    }
})
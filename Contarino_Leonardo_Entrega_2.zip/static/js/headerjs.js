var header = document.getElementById('menu')


window.addEventListener('scroll',()=>{
    var scroll = window.scrollY
    if (scrollY >10){
        header.style.backgroundColor = 'rgba(63, 22, 81, 0.7)';
        
    }
    else{
        header.style.backgroundColor = 'rgba(63, 22, 81, 1)';
        

    }
})